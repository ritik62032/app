import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ScrollArea } from "@/components/ui/scroll-area";
import ContactList from "@/components/chat/contact-list";
import MessageBubble from "@/components/chat/message-bubble";
import ChatHeader from "@/components/chat/chat-header";
import MessageInput from "@/components/chat/message-input";
import { User, Message } from "@shared/schema";
import { auth } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Chat() {
  const [selectedContact, setSelectedContact] = useState<User | null>(null);
  const { toast } = useToast();
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: ["messages", currentUser?.id, selectedContact?.id],
    enabled: !!(currentUser?.id && selectedContact?.id),
  });

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (user?.uid) {
        try {
          const res = await apiRequest("POST", "/api/users", {
            email: user.email!,
            name: user.displayName!,
            photoUrl: user.photoURL!,
            firebaseUid: user.uid,
          });
          const userData = await res.json();
          setCurrentUser(userData);
        } catch (error) {
          toast({
            variant: "destructive",
            title: "Error",
            description: "Failed to load user data",
          });
        }
      }
    });

    return () => unsubscribe();
  }, [toast]);

  if (!currentUser) {
    return <div>Loading...</div>;
  }

  return (
    <div className="flex h-screen bg-background">
      <div className="w-full md:w-80 border-r">
        <ContactList
          currentUser={currentUser}
          onSelectContact={setSelectedContact}
          selectedContact={selectedContact}
        />
      </div>
      
      <div className="flex-1 flex flex-col">
        {selectedContact ? (
          <>
            <ChatHeader contact={selectedContact} />
            <ScrollArea className="flex-1 p-4">
              {messages.map((message) => (
                <MessageBubble
                  key={message.id}
                  message={message}
                  isOwn={message.senderId === currentUser.id}
                />
              ))}
            </ScrollArea>
            <MessageInput
              currentUser={currentUser}
              recipient={selectedContact}
            />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            Select a contact to start chatting
          </div>
        )}
      </div>
    </div>
  );
}
