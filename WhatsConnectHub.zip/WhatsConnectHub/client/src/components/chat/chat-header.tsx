import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User } from "@shared/schema";

interface ChatHeaderProps {
  contact: User;
}

export default function ChatHeader({ contact }: ChatHeaderProps) {
  return (
    <div className="border-b p-4 flex items-center gap-3">
      <Avatar>
        <AvatarImage src={contact.photoUrl || undefined} />
        <AvatarFallback>
          {contact.name.charAt(0).toUpperCase()}
        </AvatarFallback>
      </Avatar>
      <div>
        <h2 className="font-medium">{contact.name}</h2>
        <p className="text-sm text-muted-foreground">{contact.email}</p>
      </div>
    </div>
  );
}
