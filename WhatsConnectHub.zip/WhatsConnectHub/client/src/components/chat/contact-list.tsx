import { User } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface ContactListProps {
  currentUser: User;
  selectedContact: User | null;
  onSelectContact: (contact: User) => void;
}

export default function ContactList({
  currentUser,
  selectedContact,
  onSelectContact,
}: ContactListProps) {
  const [search, setSearch] = useState("");
  const { data: contacts = [] } = useQuery<User[]>({
    queryKey: ["contacts", currentUser.id],
  });

  const filteredContacts = contacts.filter((contact) =>
    contact.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b">
        <Input
          placeholder="Search contacts..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>
      <ScrollArea className="flex-1">
        {filteredContacts.map((contact) => (
          <div
            key={contact.id}
            className={cn(
              "flex items-center gap-3 p-4 cursor-pointer hover:bg-secondary/20",
              selectedContact?.id === contact.id && "bg-secondary/40"
            )}
            onClick={() => onSelectContact(contact)}
          >
            <Avatar>
              <AvatarImage src={contact.photoUrl || undefined} />
              <AvatarFallback>
                {contact.name.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">{contact.name}</p>
              <p className="text-sm text-muted-foreground">{contact.email}</p>
            </div>
          </div>
        ))}
      </ScrollArea>
    </div>
  );
}
