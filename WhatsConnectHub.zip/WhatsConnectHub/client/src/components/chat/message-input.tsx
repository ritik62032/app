import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Send } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface MessageInputProps {
  currentUser: User;
  recipient: User;
}

export default function MessageInput({
  currentUser,
  recipient,
}: MessageInputProps) {
  const [message, setMessage] = useState("");
  const queryClient = useQueryClient();

  const { mutate: sendMessage, isPending } = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/messages", {
        content: message,
        senderId: currentUser.id,
        recipientId: recipient.id,
      });
    },
    onSuccess: () => {
      setMessage("");
      queryClient.invalidateQueries({
        queryKey: ["messages", currentUser.id, recipient.id],
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !isPending) {
      sendMessage();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 border-t flex gap-2">
      <Input
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Type a message..."
        className="flex-1"
      />
      <Button type="submit" size="icon" disabled={!message.trim() || isPending}>
        <Send className="h-4 w-4" />
      </Button>
    </form>
  );
}
