import { cn } from "@/lib/utils";
import { Message } from "@shared/schema";
import { format } from "date-fns";

interface MessageBubbleProps {
  message: Message;
  isOwn: boolean;
}

export default function MessageBubble({ message, isOwn }: MessageBubbleProps) {
  return (
    <div
      className={cn(
        "flex mb-4",
        isOwn ? "justify-end" : "justify-start"
      )}
    >
      <div
        className={cn(
          "max-w-[70%] rounded-lg p-3",
          isOwn
            ? "bg-primary text-primary-foreground"
            : "bg-secondary text-secondary-foreground"
        )}
      >
        <p className="break-words">{message.content}</p>
        <p className="text-xs mt-1 opacity-70">
          {format(new Date(message.timestamp), "HH:mm")}
        </p>
      </div>
    </div>
  );
}
