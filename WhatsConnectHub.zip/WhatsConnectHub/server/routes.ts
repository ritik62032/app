import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertMessageSchema, insertUserSchema } from "@shared/schema";

export async function registerRoutes(app: Express) {
  const httpServer = createServer(app);

  app.post("/api/users", async (req, res) => {
    const parsed = insertUserSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error });
    }

    const existingUser = await storage.getUserByFirebaseUid(parsed.data.firebaseUid);
    if (existingUser) {
      return res.status(200).json(existingUser);
    }

    const user = await storage.createUser(parsed.data);
    res.status(201).json(user);
  });

  app.get("/api/users/:firebaseUid", async (req, res) => {
    const user = await storage.getUserByFirebaseUid(req.params.firebaseUid);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(user);
  });

  app.get("/api/users/:userId/contacts", async (req, res) => {
    const contacts = await storage.listContacts(parseInt(req.params.userId));
    res.json(contacts);
  });

  app.get("/api/messages/:userId1/:userId2", async (req, res) => {
    const messages = await storage.getMessages(
      parseInt(req.params.userId1),
      parseInt(req.params.userId2)
    );
    res.json(messages);
  });

  app.post("/api/messages", async (req, res) => {
    const parsed = insertMessageSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error });
    }

    const message = await storage.createMessage(parsed.data);
    res.status(201).json(message);
  });

  return httpServer;
}
